import { ModelParameters, TrainingParameters, GPU_OPTIONS } from '../types/calculator';

export const bytesToString = (bytes: number): string => {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = bytes;
  let unitIndex = 0;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(2)} ${units[unitIndex]}`;
};

export const calculateModelSize = (params: ModelParameters): number => {
  // Model size in billions * precision size in bytes * 10^9
  return params.modelSize * params.precision * 1e9;
};

export const calculateKVCache = (params: ModelParameters): number => {
  // 2 * batch_size * sequence_length * num_layers * hidden_size * precision
  return 2 * params.batchSize * params.sequenceLength * 
         params.numLayers * params.hiddenSize * params.precision;
};

export const calculateActivationMemory = (params: ModelParameters): number => {
  // Using float32 (4 bytes) for activation memory as per Python code
  const activationPrecision = 4;
  return params.batchSize * params.sequenceLength * params.hiddenSize * 
         (34 + (5 * params.sequenceLength * params.numAttentionHeads) / params.hiddenSize) * 
         activationPrecision;
};

export const calculateOptimizerMemory = (params: TrainingParameters): number => {
  // Optimizer states: adamw/adam = 8 bytes per parameter, sgd = 4 bytes per parameter
  const optimizerStates = params.optimizer === 'adamw' ? 8 : 
                         params.optimizer === 'adam' ? 8 : 4;
  return (params.trainableParameters / 100) * params.modelSize * 1e9 * optimizerStates;
};

export const calculateGradientsMemory = (params: TrainingParameters): number => {
  // Using float32 (4 bytes) for gradients as per Python code
  const gradientPrecision = 4;
  return (params.trainableParameters / 100) * params.modelSize * 1e9 * gradientPrecision;
};

export const calculateRequiredGpus = (totalMemory: number, selectedGpu: string): number => {
  const gpuMemory = GPU_OPTIONS[selectedGpu].memory;
  return Math.ceil(totalMemory / gpuMemory);
};

export const calculateInferenceMemory = (params: ModelParameters) => {
  const modelWeights = calculateModelSize(params);
  const kvCache = calculateKVCache(params);
  const activationMemory = calculateActivationMemory(params);
  const total = modelWeights + kvCache + activationMemory;
  const requiredGpus = calculateRequiredGpus(total, params.selectedGpu);
  
  return {
    modelWeights,
    kvCache,
    activationMemory,
    total,
    requiredGpus
  };
};

export const calculateTrainingMemory = (params: TrainingParameters) => {
  const modelWeights = calculateModelSize(params);
  const kvCache = calculateKVCache(params);
  const activationMemory = calculateActivationMemory(params);
  const optimizerMemory = calculateOptimizerMemory(params);
  const gradientsMemory = calculateGradientsMemory(params);
  const total = modelWeights + kvCache + activationMemory + optimizerMemory + gradientsMemory;
  const requiredGpus = calculateRequiredGpus(total, params.selectedGpu);
  
  return {
    modelWeights,
    kvCache,
    activationMemory,
    optimizerMemory,
    gradientsMemory,
    total,
    requiredGpus
  };
};