import React, { useState, useEffect } from 'react';
import { Calculator, Brain, Cpu } from 'lucide-react';
import { 
  ModelParameters, 
  TrainingParameters,
  PRECISION_OPTIONS,
  OPTIMIZER_OPTIONS,
  GPU_OPTIONS
} from '../types/calculator';
import { MODEL_CONFIGS } from '../types/models';
import { 
  calculateInferenceMemory, 
  calculateTrainingMemory,
} from '../utils/memoryCalculations';
import { ResultCard } from './ResultCard';

const defaultParams: TrainingParameters = {
  modelSize: 1,
  precision: 4,
  batchSize: 1,
  sequenceLength: 2048,
  hiddenSize: 2048,
  numLayers: 24,
  numAttentionHeads: 16,
  optimizer: 'adamw',
  trainableParameters: 100,
  selectedGpu: 'GM301(80G)'
};

export const ModelCalculator: React.FC = () => {
  const [params, setParams] = useState<TrainingParameters>(defaultParams);
  const [activeTab, setActiveTab] = useState<'inference' | 'training'>('inference');
  const [selectedModel, setSelectedModel] = useState<string>('none');

  useEffect(() => {
    if (selectedModel !== 'none') {
      const modelConfig = MODEL_CONFIGS[selectedModel];
      setParams(prev => ({
        ...prev,
        modelSize: modelConfig.model_size,
        hiddenSize: modelConfig.hidden_size,
        numAttentionHeads: modelConfig.num_attention_heads,
        numLayers: modelConfig.num_hidden_layers,
        precision: modelConfig.torch_dtype === 'bfloat16' ? 2 : 4
      }));
    }
  }, [selectedModel]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'selectedModel') {
      setSelectedModel(value);
    } else {
      setParams(prev => ({
        ...prev,
        [name]: name === 'optimizer' || name === 'selectedGpu' ? value : value === '' ? '' : Number(value)
      }));
    }
  };

  const inferenceMemory = calculateInferenceMemory(params);
  const trainingMemory = calculateTrainingMemory(params);

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <div className="flex space-x-4 border-b border-gray-200">
          <button
            className={`px-6 py-3 font-medium transition-all duration-200 ease-in-out ${
              activeTab === 'inference'
                ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/50'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            } rounded-t-lg`}
            onClick={() => setActiveTab('inference')}
          >
            推理
          </button>
          <button
            className={`px-6 py-3 font-medium transition-all duration-200 ease-in-out ${
              activeTab === 'training'
                ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/50'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            } rounded-t-lg`}
            onClick={() => setActiveTab('training')}
          >
            训练
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 hover:shadow-xl transition-shadow duration-300">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2 text-gray-800">
              <Calculator className="w-5 h-5 text-blue-500" />
              模型参数设置
            </h2>
          
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  选择模型
                </label>
                <select
                  name="selectedModel"
                  value={selectedModel}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                >
                  {Object.entries(MODEL_CONFIGS).map(([key, config]) => (
                    <option key={key} value={key}>
                      {config.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  显卡型号
                </label>
                <select
                  name="selectedGpu"
                  value={params.selectedGpu}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                >
                  {Object.keys(GPU_OPTIONS).map(gpu => (
                    <option key={gpu} value={gpu}>
                      {gpu}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  模型规模（十亿参数）
                </label>
                <input
                  type="text"
                  name="modelSize"
                  value={params.modelSize}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  精度
                </label>
                <select
                  name="precision"
                  value={params.precision}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                >
                  {PRECISION_OPTIONS.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  批次大小
                </label>
                <input
                  type="text"
                  name="batchSize"
                  value={params.batchSize}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  序列长度
                </label>
                <input
                  type="text"
                  name="sequenceLength"
                  value={params.sequenceLength}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  隐藏层大小
                </label>
                <input
                  type="text"
                  name="hiddenSize"
                  value={params.hiddenSize}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  层数
                </label>
                <input
                  type="text"
                  name="numLayers"
                  value={params.numLayers}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  注意力头数
                </label>
                <input
                  type="text"
                  name="numAttentionHeads"
                  value={params.numAttentionHeads}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                />
              </div>

              {activeTab === 'training' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      优化器
                    </label>
                    <select
                      name="optimizer"
                      value={params.optimizer}
                      onChange={handleInputChange}
                      className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                    >
                      {OPTIMIZER_OPTIONS.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      可训练参数比例 (%)
                    </label>
                    <input
                      type="text"
                      name="trainableParameters"
                      value={params.trainableParameters}
                      onChange={handleInputChange}
                      className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-2 space-y-6">
          {activeTab === 'inference' ? (
            <ResultCard
              title="推理显存需求"
              memory={inferenceMemory}
              type="inference"
              selectedGpu={params.selectedGpu}
            />
          ) : (
            <ResultCard
              title="训练显存需求"
              memory={trainingMemory}
              type="training"
              selectedGpu={params.selectedGpu}
            />
          )}
        </div>
      </div>
    </div>
  );
};