import React from 'react';
import { MemoryCalculation, TrainingMemoryCalculation } from '../types/calculator';
import { bytesToString } from '../utils/memoryCalculations';
import { Cpu } from 'lucide-react';

interface ResultCardProps {
  title: string;
  memory: MemoryCalculation | TrainingMemoryCalculation;
  type: 'inference' | 'training';
  selectedGpu: string;
}

export const ResultCard: React.FC<ResultCardProps> = ({ title, memory, type, selectedGpu }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-8 hover:shadow-xl transition-shadow duration-300">
      <h3 className="text-2xl font-semibold mb-6 flex items-center gap-2 text-gray-800">
        <Cpu className="w-6 h-6 text-blue-500" />
        {title}
      </h3>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <span className="text-sm text-gray-600">模型权重</span>
            <div className="font-mono text-lg font-medium text-gray-900 mt-1">
              {bytesToString(memory.modelWeights)}
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <span className="text-sm text-gray-600">KV缓存</span>
            <div className="font-mono text-lg font-medium text-gray-900 mt-1">
              {bytesToString(memory.kvCache)}
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <span className="text-sm text-gray-600">激活值内存</span>
            <div className="font-mono text-lg font-medium text-gray-900 mt-1">
              {bytesToString(memory.activationMemory)}
            </div>
          </div>
          {type === 'training' && 'optimizerMemory' in memory && (
            <>
              <div className="bg-gray-50 rounded-lg p-4">
                <span className="text-sm text-gray-600">优化器内存</span>
                <div className="font-mono text-lg font-medium text-gray-900 mt-1">
                  {bytesToString(memory.optimizerMemory)}
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <span className="text-sm text-gray-600">梯度内存</span>
                <div className="font-mono text-lg font-medium text-gray-900 mt-1">
                  {bytesToString(memory.gradientsMemory)}
                </div>
              </div>
            </>
          )}
        </div>
        <div className="mt-6 pt-4 border-t border-gray-100">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="text-blue-900 font-medium">总计所需显存</span>
              <div className="text-right">
                <span className="font-mono text-xl font-bold text-blue-700 block">
                  {bytesToString(memory.total)}
                </span>
                <span className="text-sm text-blue-600">
                  需要 {memory.requiredGpus} 张 {selectedGpu}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};