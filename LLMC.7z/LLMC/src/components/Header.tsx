import React from 'react';
import { Cpu, Layers } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 border-b border-white/10">
      <div className="container mx-auto px-4 py-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-white p-2 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" className="w-8 h-8">
                <path fill="#e6002d" d="M701.7 443.2a102.9 102.9 0 0 0-12.3-0.8 101.7 101.7 0 0 0-66.3 24.5 136.4 136.4 0 1 0-246.1 0 101.7 101.7 0 0 0-66.3-24.5A102.1 102.1 0 1 0 397 598.9a101.7 101.7 0 0 0 10.8-85.7 61.1 61.1 0 0 1 26.7 20l2.6 3.8a81.2 81.2 0 0 1 130.7-3.2l4.7 6.7 50.5 72.2a81.7 81.7 0 0 0 60.9 33.8l5.4 0a102.1 102.1 0 0 0 12.3-203.4ZM500 0a500 500 0 1 0 500 500A500 500 0 0 0 500 0ZM696.1 715.2l-6.7 0a148.7 148.7 0 0 1-117.6-57.6S497.3 551.4 496.1 550a41.1 41.1 0 0 0-55.2-7.5l120 171.3a60.9 60.9 0 0 0 75.1 20 95.1 95.1 0 0 1-149.2-6.6l-48.3-69a170.8 170.8 0 1 1-140-283.7 204.8 204.8 0 0 1 404.1 0 170.8 170.8 0 0 1-6 341Z" />
              </svg>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">
                LLM计算器
              </h1>
              <p className="text-blue-100 text-sm">大语言模型显存计算工具</p>
            </div>
          </div>
          
          <nav className="flex items-center">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-1">
              <ul className="flex space-x-1">
                <li>
                  <a 
                    href="#" 
                    className="flex items-center space-x-2 px-4 py-2 rounded-lg text-white hover:bg-white/10 transition-colors duration-200"
                  >
                    <Cpu className="w-4 h-4" />
                    <span>推理</span>
                  </a>
                </li>
                <li>
                  <a 
                    href="#" 
                    className="flex items-center space-x-2 px-4 py-2 rounded-lg text-white hover:bg-white/10 transition-colors duration-200"
                  >
                    <Layers className="w-4 h-4" />
                    <span>训练</span>
                  </a>
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}