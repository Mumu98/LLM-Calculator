export interface ModelParameters {
  modelSize: number;
  precision: number;
  batchSize: number;
  sequenceLength: number;
  hiddenSize: number;
  numLayers: number;
  numAttentionHeads: number;
  selectedGpu: string;
}

export interface TrainingParameters extends ModelParameters {
  optimizer: string;
  trainableParameters: number;
}

export interface MemoryCalculation {
  modelWeights: number;
  kvCache: number;
  activationMemory: number;
  total: number;
  requiredGpus: number;
}

export interface TrainingMemoryCalculation extends MemoryCalculation {
  optimizerMemory: number;
  gradientsMemory: number;
}

export const PRECISION_OPTIONS = [
  { label: 'FP32 / Full-precision', value: 4 },
  { label: 'FP16 / float16', value: 2 },
  { label: 'int8', value: 1 },
  { label: 'int4', value: 0.5 },
];

export const OPTIMIZER_OPTIONS = [
  { label: 'AdamW', value: 'adamw' },
  { label: 'Adam', value: 'adam' },
  { label: 'SGD', value: 'sgd' },
];

export const GPU_OPTIONS = {
  'GDP401(24G)': { memory: 24 * 1024 * 1024 * 1024 },
  'GM301-1(40G)': { memory: 40 * 1024 * 1024 * 1024 },
  'GM301(80G)': { memory: 80 * 1024 * 1024 * 1024 },
  'GM402(80G)': { memory: 80 * 1024 * 1024 * 1024 },
  'GM302(80G)': { memory: 80 * 1024 * 1024 * 1024 },
  'GM302(40G)': { memory: 40 * 1024 * 1024 * 1024 },
  'V100(32G)': { memory: 32 * 1024 * 1024 * 1024 },
  'V100(16G)': { memory: 16 * 1024 * 1024 * 1024 },
};