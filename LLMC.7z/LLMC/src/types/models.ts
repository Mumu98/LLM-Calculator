export interface ModelConfig {
  model_size: number;
  hidden_size: number;
  num_attention_heads: number;
  num_hidden_layers: number;
  torch_dtype: string;
  name: string;
}

export const MODEL_CONFIGS: { [key: string]: ModelConfig } = {
  "none": {
    name: "Custom Configuration",
    model_size: 1,
    hidden_size: 2048,
    num_attention_heads: 16,
    num_hidden_layers: 24,
    torch_dtype: "float32"
  },
  "meta-llama-3-70b-instruct": {
    name: "Meta Llama 3 70B Instruct",
    model_size: 70,
    hidden_size: 8192,
    num_attention_heads: 64,
    num_hidden_layers: 80,
    torch_dtype: "bfloat16"
  },
  "meta-llama-3-8b-instruct": {
    name: "Meta Llama 3 8B Instruct",
    model_size: 8,
    hidden_size: 4096,
    num_attention_heads: 32,
    num_hidden_layers: 32,
    torch_dtype: "bfloat16"
  },
  "meta-llama-3-8b": {
    name: "Meta Llama 3 8B",
    model_size: 8,
    hidden_size: 4096,
    num_attention_heads: 32,
    num_hidden_layers: 32,
    torch_dtype: "bfloat16"
  },
  "qwen2-72b-instruct": {
    name: "Qwen2 72B Instruct",
    model_size: 72,
    hidden_size: 8192,
    num_attention_heads: 64,
    num_hidden_layers: 80,
    torch_dtype: "bfloat16"
  }
};